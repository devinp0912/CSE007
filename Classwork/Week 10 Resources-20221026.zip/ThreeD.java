public class ThreeD {
    public static void main(String [] args){
        int [][][] threeD = new int [2][3][4];
        threeD[0][0][0] = 50;
        threeD[0][0][1] = 60;
        threeD[0][0][2] = 70;
        threeD[0][0][3] = 80;
        threeD[0][1][0] = 90;
        threeD[0][1][1] = 100;
        threeD[0][1][2] = 50;
        threeD[0][1][3] = 70;
        threeD[0][2][0] = 90;
        threeD[0][2][1] = 60;
        threeD[0][2][2] = 80;
        threeD[0][2][3] = 100;
        threeD[1][0][0] = 60;
        threeD[1][0][1] = 70;
        threeD[1][0][2] = 80;
        threeD[1][0][3] = 90;
        threeD[1][1][0] = 100;
        threeD[1][1][1] = 60;
        threeD[1][1][2] = 70;
        threeD[1][1][3] = 80;
        threeD[1][2][0] = 90;
        threeD[1][2][1] = 100;
        threeD[1][2][2] = 60;
        threeD[1][2][3] = 70;
        for(int depth = 0; depth < threeD.length;depth++){
            for(int row = 0; row < threeD[depth].length; row++){
                for(int col = 0; col < threeD[depth][row].length; col++){
                    System.out.print(threeD[depth][row][col] + " ");
                }
                System.out.println();
            }
        }
        //each section average for cse007 and cse017
        
    
        // find average for the course CSE007 and CSE017
        
    
    }
    
}
